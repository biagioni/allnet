//
//  iOSKeys.h
//  xchat UI
//
//  Created by e on 2015/10/03.
//  Copyright © 2015 allnet. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface iOSKeys : NSObject

- (void) createIOSKey;

@end
