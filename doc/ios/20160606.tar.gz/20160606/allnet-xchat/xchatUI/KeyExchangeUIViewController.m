//
//  KeyExchangeUIViewController.m
//  xchat UI
//
//  Created by e on 2015/07/13.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import "KeyExchangeUIViewController.h"
#import "AppDelegate.h"

@interface KeyExchangeUIViewController ()

@property UIButton * cancelButton;
@property UIButton * resendButton;
@property NSString * contactName;

@property UILabel * exchangingWith;
@property UITextView * secretView;
@property UITextView * progressView;

@property BOOL keyExchangeCompleted;

@end


@implementation KeyExchangeUIViewController

- (void) viewDidLoad {
    [super viewDidLoad];
    if (self.cancelButton != nil)
        [self.cancelButton addTarget:self action:@selector(cancelButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    if (self.resendButton != nil)
        [self.resendButton addTarget:self action:@selector(resendButtonClicked:)forControlEvents:UIControlEventTouchUpInside];
}

- (void) initializeWindow:(NSString *) contact secret1: (NSString *) s1 secret2: (NSString *) s2 {
    self.cancelButton = nil;
    self.resendButton = nil;
    self.secretView = nil;
    self.progressView = nil;
    self.contactName = contact;
    self.exchangingWith = nil;
    self.keyExchangeCompleted = NO;
    UIView * v = self.view;
    NSArray * subviews = v.subviews;
    // NSLog(@"subviews are %@\n", subviews);
    for (NSObject * item in subviews) {  // create self.message first, used in self.conversation initialize
        // NSLog(@"subview %@\n", item);
        if ([item isMemberOfClass: [UITextView class]]) {
            UITextView * tv = (UITextView *) item;
            // NSLog(@"found text view %@, color %@\n", tv.text, tv.backgroundColor);
            NSString * start = nil;
            if ((tv.text != nil) && (tv.text.length > 6))
                start = [tv.text substringToIndex:6];
            if (start != nil) {
                if ([@"shared" isEqualToString:start]) {
                    self.secretView = tv;
                    if ((s2 == nil) || (s2.length < 1))
                        self.secretView.text = [[NSString alloc] initWithFormat:@"Shared secret:\n%@", s1];
                    else
                        self.secretView.text = [[NSString alloc] initWithFormat:@"Shared secret:\n%@\nor:\n%@", s1, s2];
                } else if ([@"Key ex" isEqualToString:start]) {
                    self.progressView = tv;
                    self.progressView.text = [self.progressView.text stringByAppendingString:contact];
                }
            }
        } else if ([item isMemberOfClass:[UIButton class]]) {
            UIButton * button = (UIButton *) item;
            NSLog(@"found button %@/%@\n", button, button.titleLabel);
            if ([@"resend your key" isEqualToString:button.titleLabel.text]) {
                self.resendButton = button;
                [self.resendButton addTarget:self action:@selector(resendButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            }
            if ([@"cancel" isEqualToString:button.titleLabel.text]) {
                self.cancelButton = button;
                [self.cancelButton addTarget:self action:@selector(cancelButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            }
        } else if ([ item isMemberOfClass:[UILabel class]]) {
            self.exchangingWith = (UILabel *) item;
            self.exchangingWith.text = [self.exchangingWith.text stringByAppendingString:contact];
            // NSLog(@"exchanging with %@\n", self.exchangingWith.text);
        }
    }
    // NSLog(@"contact %@, secrets %@ and %@, buttons %@ and %@, views %@ and %@\n", contact, s1, s2, self.resendButton, self.cancelButton, self.secretView, self.progressView);
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"in prepareForSegue in KeyExchangeUIViewController.m, segue %@/%p\n", segue.identifier, segue);
    NSLog(@"contact name %@, segue destination is %@\n", self.contactName, [segue destinationViewController]);
}

- (void) notificationOfGeneratedKey: (NSString *) contact {
    if ([self.contactName isEqualToString:contact]) {
        // self.progressView.text = @"Key received successfully";
        // should replace "Generating key" with "Sent your key"
        NSLog(@"notified of key generation, text is %@\n", self.progressView.text);
        NSMutableString * replaceable = [[NSMutableString alloc] initWithString:self.progressView.text];
        NSRange all;
        all.location = 0;
        all.length = replaceable.length;
        [replaceable replaceOccurrencesOfString:@"Generating" withString:@"Sent" options:NSLiteralSearch range:all];
        self.progressView.text = [[NSString alloc] initWithUTF8String: replaceable.UTF8String];
        // NSLog(@"      new text is %@\n", self.progressView.text);
        [self.view setNeedsDisplay];
    }
    NSLog(@"KeyExchangeUIViewController.m notified of completed key generation with '%@', self '%@'\n", contact, self.contactName);
}

- (void) notificationOfCompletedKeyExchange: (NSString *) contact {
    if ([self.contactName isEqualToString:contact]) {
        NSLog(@"%@ isEqualToString %@\n", self.contactName, contact);
    }
        self.keyExchangeCompleted = YES;
        self.progressView.backgroundColor = UIColor.greenColor;
        self.progressView.text = @"Key received successfully";
        self.secretView.text = @"";
        self.secretView.hidden = YES;
        self.exchangingWith.text = [[NSString alloc] initWithFormat:@"Got key from %@\n", self.contactName];
        self.cancelButton.titleLabel.text = @"done";
        [self.view setNeedsDisplay];
    NSLog(@"KeyExchangeUIViewController.m notified of completed key exchange with '%@' (%lu), self '%@' (%lu)\n",
          contact, (unsigned long)contact.length, self.contactName, (unsigned long)self.contactName.length);
}

- (IBAction)cancelButtonClicked:(id)sender
{
    if (self.keyExchangeCompleted)
        NSLog(@"key exchange done button clicked\n");
    else {
        NSLog(@"cancel button clicked\n");
        AppDelegate * appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
        XChat * socket = appDelegate.xChat;
        [socket removeNewContact:self.contactName];
    }
}

- (IBAction)resendButtonClicked:(id)sender
{
    NSLog(@"resend key button clicked\n");
    AppDelegate * appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    XChat * socket = appDelegate.xChat;
    [socket resendKeyForNewContact:self.contactName];
}

@end
