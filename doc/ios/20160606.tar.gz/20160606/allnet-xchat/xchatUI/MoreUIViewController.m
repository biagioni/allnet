//
//  MoreUIViewController.m
//  xchat UI
//
//  Created by e on 2015/11/08.
//  Copyright © 2015 allnet. All rights reserved.
//

#import "MoreUIViewController.h"
#import "AppDelegate.h"

@interface MoreUIViewController ()

@property UIButton * traceButton;
@property UITextView * textView;

@end

@implementation MoreUIViewController

- (void) viewDidLoad {
    NSLog(@"More viewDidLoad\n");
    [super viewDidLoad];
    self.traceButton = nil;
    self.textView = nil;
    NSLog(@"More viewDidLoad, subviews are %@\n", self.view.subviews);
    UIScrollView * sv = self.view.subviews [0];
    NSLog(@"More sub-subviews are %@\n", sv.subviews);
    for (NSObject * item in sv.subviews) {  // create self.traceButton
        // NSLog(@"subview %@\n", item);
        if ((self.traceButton == nil) && ([item isMemberOfClass: [UIButton class]])) {
            UIButton * button = (UIButton *) item;
            NSLog(@"subview %@, title %@\n", item, button.currentTitle);
            if ([button.currentTitle isEqualToString:@"Trace"]) {
                self.traceButton = (UIButton *) item;
                NSLog(@"found trace button\n");
            }
        }
        if ((self.textView == nil) && ([item isMemberOfClass: [UITextView class]])) {
            self.textView = (UITextView *) item;
            CGFloat fontSize = [[UIFont preferredFontForTextStyle:UIFontTextStyleBody] lineHeight];
            fontSize *= 0.6;  // make it a little smaller
            NSLog(@"font name is %@\n", self.textView.font.fontName);
            UIFont * font = [UIFont fontWithName:self.textView.font.fontName size:fontSize];
            [self.textView setFont:font];
        }
    }
    if (self.traceButton != nil)
        [self.traceButton addTarget:self action:@selector(traceButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void) initializeWindow:(NSString *) contact secret1: (NSString *) s1 secret2: (NSString *) s2 {
    NSLog(@"More initializeWindow\n");
    [self viewDidLoad];
}

static UITextView * tv = nil;

#define START_MESSAGE   "starting trace"

void rcvTrace (const char * trace)
{
    if (tv != nil) {
        if (strcmp (tv.text.UTF8String, START_MESSAGE) == 0)
            tv.text = @"";
printf ("appending to trace: '%s'\n", trace);
        tv.text = [tv.text stringByAppendingFormat:@"%s", trace];
        [tv setNeedsDisplay];
    }
}

- (IBAction)traceButtonClicked:(id)sender
{
    NSLog(@"trace button clicked\n");
    if (self.textView != nil) {
        // NSLog(@"text view width is %f\n", self.view.frame.size.width);
        BOOL wide_enough = (self.view.frame.size.width > 500.0f);
        // NSLog(@"wide_enough is %s\n", (wide_enough) ? "true" : "false");
        self.textView.text = @START_MESSAGE;
        [self.textView setNeedsDisplay];  // but never displayed, only effective after we return
        AppDelegate * appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
        XChat * socket = appDelegate.xChat;

#define INCREMENTAL_TRACE
#ifdef INCREMENTAL_TRACE
        tv = self.textView;
        [socket startTrace:&rcvTrace wide:wide_enough];
#else /* ! INCREMENTAL_TRACE, so wait for the trace before displaying */
        NSString * trace = [socket trace:wide];
        self.textView.text = trace;
#endif /* INCREMENTAL_TRACE */
    }
    [self.textView setNeedsDisplay];
}


@end
