//
//  NewContactViewController.m
//  xchat UI
//
//  Created by e on 2015/04/25.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import "AppDelegate.h"
#import "NewContactViewController.h"
#import "XChat.h"
#import "KeyExchangeUIViewController.h"

#include "lib/util.h"
#include "xchat/cutil.h"

@interface NewContactViewController ()

@property NSArray * selectionArray;
@property NSInteger selected;
@property NSString * contactGeneratedSecret;

@end

@implementation NewContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //NSLog(@"new contact view controller: view controllers has %@, picker has %@\n", self.tabBarController.viewControllers, self.contactTypePicker);
    self.selectionArray = @[@"regular internet contact", @"nearby wireless contact", @"subscribe to a broadcast"];
    self.selectionArray = @[@"regular internet contact", @"nearby wireless contact"];
    self.selected = 0;   // default
    // initialize the picker to specify the type of contact
    self.contactTypePicker.dataSource = self;
    self.contactTypePicker.delegate = self;
    // initialize the go button
    [self.contactGoButton addTarget:self action:@selector(goButtonClicked:)
                   forControlEvents:UIControlEventTouchUpInside];
    self.kev = nil;
    //NSURL*url = [[NSBundle mainBundle] URLForResource:@"contacts" withExtension:@""];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSLog(@"received memory warning\n");
}

// number of columns of data
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// number of columns of data
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.selectionArray.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return self.selectionArray[row];
}

- (void)viewWillAppear:(BOOL)Animated {
    [super viewWillAppear: Animated];
    NSLog(@"\nnew contact view controller: view will appear\n\n");
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    // NSLog(@"selected row %d\n", (int) row);
    self.selected = row;
    if (row == 0)
        NSLog(@"new contact is at a distance\n");
    else if (row == 1)
        NSLog(@"new contact is in wireless range\n");
    else
        NSLog(@"subscribing");
}

- (void) createRequest: (KeyExchangeUIViewController *) destination
{
    AppDelegate * appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    XChat * socket = appDelegate.xChat;
    if ((self.selected == 0) || (self.selected == 1)) {  // exchanging keys
        int hops = 6;
        if (self.selected == 1) {  // in local wireless range
            hops = 1;
            // self.contactGeneratedSecret = [self.contactGeneratedSecret substringToIndex:6];
        }
        [socket requestNewContact:self.contactName.text
                          maxHops:hops
                          secret1:self.contactGeneratedSecret
                  optionalSecret2:self.contactSecret.text
                      keyExchange:destination];
    } else {  // request key
        [socket requestKey:self.contactName.text maxHops: 10];
    }
}

- (IBAction)goButtonClicked:(id)sender
{
    NSLog(@"clicked, text fields are '%@' and '%@', generated secret %@, self.selected %d\n", self.contactName.text, self.contactSecret.text, self.contactGeneratedSecret, (int)self.selected);
    // we now create the request in prepareForSegue, so it is after initializing the window.
    // that is important because otherwise the reply might be received before the window is
    // set up, and the window code in KeyExchangeViewController.m/initializeWindow can't handle that
    //[self createRequest];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"in prepareForSegue in NewContactViewController.m, segue %@/%p\n", segue.identifier, segue);
    NSLog(@"segue destination is %@\n", [segue destinationViewController]);
    self.kev = [segue destinationViewController];
#define MAX_RANDOM  15   // 14 characters plus a null character
    char randomString [MAX_RANDOM];
    random_string(randomString, MAX_RANDOM);
    normalize_secret(randomString);
    self.contactGeneratedSecret = [[NSString alloc] initWithUTF8String:randomString];
    if (self.selected == 1)
        self.contactGeneratedSecret = [self.contactGeneratedSecret substringToIndex:6];
    NSObject * destinationObject = [segue destinationViewController];
    if ([destinationObject isMemberOfClass:[KeyExchangeUIViewController class]]) {
        KeyExchangeUIViewController * destination = (KeyExchangeUIViewController *) destinationObject;
        NSLog(@"calling initializeWindow %@ %@ %@, selected = %d\n", self.contactName, self.contactGeneratedSecret, self.contactSecret, (int)self.selected);
        NSString * contact = nil;
        if (self.contactName != nil)
            contact = self.contactName.text;
        NSString * enteredSecret = nil;
        if (self.contactSecret != nil)
            enteredSecret = self.contactSecret.text;
        
        [destination initializeWindow:contact secret1:self.contactGeneratedSecret secret2: enteredSecret];
        [self createRequest: destination];
    }
}

@end
