//
//  ConversationViewController.m
//  xchat UI
//
//  Created by e on 2015/07/06.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import "ConversationViewController.h"
#import "ConversationUITextView.h"

@interface ConversationViewController ()

@property ContactsUITableViewController * tvc;

@property UIScrollView * scrollView;

@property ConversationUITextView * textView;

@end

// mostly needed so we know when the conversation is visible, so we can know whether a contact has new messages
// there may be an easier way to do this, but I don't know what that would be.

@implementation ConversationViewController

- (void)notifyChange: (ContactsUITableViewController *) contactsUI {
    self.tvc = contactsUI;
}

- (void)initTextViewFrame {
    NSLog (@"initializing text view frame, currently %f %f, %f x %f, scroll view %@\n",
           self.textView.frame.origin.x, self.textView.frame.origin.y,
           self.textView.frame.size.width, self.textView.frame.size.height, self.scrollView);
    CGRect textFrame;
    textFrame.origin.x = 0;
    textFrame.origin.y = 0;
    textFrame.size.height = TEXTVIEWSIZE;  // maximum allowed
    textFrame.size.width = self.scrollView.frame.size.width;
    [self.textView setFrame:textFrame];
    CGPoint scrollOffset;
    scrollOffset.x = 0;
    scrollOffset.y = self.textView.frame.size.height - self.scrollView.frame.size.height;
    NSLog (@"initialized  text view frame, currently %f %f, %f x %f, scroll view %@\n",
           self.textView.frame.origin.x, self.textView.frame.origin.y,
           self.textView.frame.size.width, self.textView.frame.size.height, self.scrollView);
}

- (void)initSubViews {
    static int initialized = 0;
    if (initialized) {
        return;
    }
    initialized = 1;
    self.scrollView = nil;
    self.textView = nil;

    CGRect actualFrame = self.view.frame;
    NSLog(@"view frame is %@\n", self.view);
    int viewWidth = actualFrame.size.width - 32;
    int viewHeight = actualFrame.size.height - 176;  // should be related to size of other windows
    for (NSObject * item in self.view.subviews) {
        // NSLog(@"ConversationViewController view.subview %@\n", item);
        if ([item isKindOfClass: [UITextView class]]) {
            self.scrollView = (UIScrollView *) item;
        }
    }
    if (self.scrollView != nil) {
        NSLog(@"scroll view is %@\n", self.scrollView);
                    [self.scrollView setFrame: actualFrame];
        CGRect scrollFrame = self.scrollView.frame;
        scrollFrame.origin.x = 16;
        scrollFrame.origin.y = 73;   // reflects the position below the contact name
        scrollFrame.size.width = viewWidth;
        scrollFrame.size.height = viewHeight;
        [self.scrollView setFrame: scrollFrame];
        NSArray * subviews = self.scrollView.subviews;
        for (NSObject * item in subviews) {
            // NSLog(@"ConversationViewController scrollView.subview %@\n", item);
            if ([item isMemberOfClass: [ConversationUITextView class]]) {
                self.textView = (ConversationUITextView *) item;
                [self initTextViewFrame];
            }
        }
        if ((self.scrollView != nil) && ([self.scrollView isMemberOfClass: [ConversationUITextView class]])) {
            self.textView = (ConversationUITextView *) self.scrollView;
            [self initTextViewFrame];
        }
        NSLog(@"scroll view is now %@\n", self.scrollView);
        NSLog(@"text view is now %@\n", self.textView);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"\nConversationViewController view did load for %@\n", self.view);
    [self initSubViews];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear: animated];
    NSLog(@"\nConversationViewController view did appear for %@\n", self.view);
    // NSLog(@"child view controllers: %@\n", self.childViewControllers);
    [self initSubViews];
    if (self.scrollView != nil) {
        NSLog(@"self.scrollView %@ subviews: %@\n", self.scrollView, self.scrollView.subviews);
    }
    if (self.tvc != nil)
        [self.tvc notify:YES];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    //NSLog(@"\nview did disappear\n\n");
    if (self.tvc != nil)
        [self.tvc notify:YES];
}

@end
