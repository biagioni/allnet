//
//  KeyExchangeUIViewController.h
//  xchat UI
//
//  Created by e on 2015/07/13.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyExchangeUIViewController : UIViewController

- (void) initializeWindow:(NSString *) contact secret1: (NSString *) s1 secret2: (NSString *) s2;

- (void) notificationOfCompletedKeyExchange: (NSString *) contact;
- (void) notificationOfGeneratedKey: (NSString *) contact;

@end
