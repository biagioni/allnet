//
//  KeyExchangeUIView.m
//  xchat UI
//
//  Created by e on 2015/07/11.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import "KeyExchangeUIView.h"
// unused I think, may be able to delete

@implementation KeyExchangeUIView

@end
