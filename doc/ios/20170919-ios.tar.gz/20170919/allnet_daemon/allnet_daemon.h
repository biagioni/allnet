//
//  allnet_daemon.h
//  allnet_daemon
//
//  Created by e on 2015/05/25.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface allnet_daemon : NSObject

@end
