//
//  KeyExchangeUIView.h
//  xchat UI
//
//  Created by e on 2015/07/11.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyExchangeUIView : UIView<UIScrollViewDelegate>

@end
