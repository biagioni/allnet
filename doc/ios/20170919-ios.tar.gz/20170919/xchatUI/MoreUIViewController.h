//
//  MoreUIViewController.h
//  xchat UI
//
//  Created by e on 2015/11/08.
//  Copyright © 2015 allnet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreUIViewController : UIViewController

@end
