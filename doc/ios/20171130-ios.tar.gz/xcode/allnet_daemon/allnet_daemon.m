//
//  allnet_daemon.m
//  allnet_daemon
//
//  Created by e on 2015/05/25.
//  Copyright (c) 2015 allnet. All rights reserved.
//

#import "allnet_daemon.h"

@implementation allnet_daemon

@end
